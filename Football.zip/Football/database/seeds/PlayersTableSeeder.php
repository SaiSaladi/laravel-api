<?php

use Illuminate\Database\Seeder;
use App\Players;
use App\Teams;
class PlayersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Players::truncate();

        $faker = \Faker\Factory::create();
        $teams = Teams::all()->pluck('id')->toArray();

        // And now, let's create a few Players in our database:
        for ($i = 0; $i < 5; $i++) {
            $team_id = $faker->randomElement($teams);
            Players::create([
                'first_name' => $faker->firstName,
                'last_name' => $faker->lastName,
                'team_id' => $team_id,
            ]);
        }
    }
}
