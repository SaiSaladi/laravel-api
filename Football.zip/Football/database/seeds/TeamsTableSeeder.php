<?php

use Illuminate\Database\Seeder;
use App\Teams;

class TeamsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Teams::truncate();

        $faker = \Faker\Factory::create();

        // And now, let's create a few Players in our database:
        for ($i = 0; $i < 5; $i++) {
            Players::create([
                'name' => $faker->firstName,
            ]);
        }
    }
}
